
const DB_NAME = 'remote-jobs-hub-db';
const STORE_NAME = 'jobs';
const DB_VERSION = 1;

const CATEGORY_LABELS = {
  all: 'All',
  tech: 'Tech & IT',
  support: 'Customer support',
  ops: 'Operations & admin',
  creative: 'Writing & creative',
  sales: 'Sales & marketing',
  other: 'Other'
};

const STATUS_LABELS = {
  all: 'Any',
  saved: 'Saved',
  applied: 'Applied',
  interview: 'Interview',
  offer: 'Offer',
  closed: 'Closed'
};

const REGION_LABELS = {
  all: 'Any',
  global: 'Global',
  africa: 'Africa-friendly',
  emea: 'EMEA',
  americas: 'Americas',
  apac: 'APAC'
};

const demoJobs = [
  {
    id: crypto.randomUUID(),
    title: 'Frontend Engineer',
    company: 'AsyncCloud',
    url: 'https://example.com/frontend-engineer',
    category: 'tech',
    region: 'global',
    status: 'saved',
    tags: ['React', 'TypeScript', 'SaaS'],
    notes: 'Strong match for frontend and product work. Prioritise this one first.',
    createdAt: new Date().toISOString()
  },
  {
    id: crypto.randomUUID(),
    title: 'Customer Support Specialist',
    company: 'CalmInbox',
    url: 'https://example.com/customer-support-specialist',
    category: 'support',
    region: 'africa',
    status: 'applied',
    tags: ['Email', 'Chat', 'Remote support'],
    notes: 'Application submitted. Follow up in one week.',
    createdAt: new Date().toISOString()
  },
  {
    id: crypto.randomUUID(),
    title: 'Remote Operations Coordinator',
    company: 'Atlas Assist',
    url: 'https://example.com/ops-coordinator',
    category: 'ops',
    region: 'emea',
    status: 'interview',
    tags: ['Scheduling', 'Admin', 'Operations'],
    notes: 'Interview booked. Review team workflows and async tools.',
    createdAt: new Date().toISOString()
  }
];

let db;
let jobs = [];
let editingId = null;
const filters = { search: '', category: 'all', status: 'all', region: 'all' };

const els = {
  jobForm: document.getElementById('jobForm'),
  jobList: document.getElementById('jobList'),
  searchInput: document.getElementById('searchInput'),
  resultsText: document.getElementById('resultsText'),
  categoryFilters: document.getElementById('categoryFilters'),
  statusFilters: document.getElementById('statusFilters'),
  regionFilters: document.getElementById('regionFilters'),
  totalJobsStat: document.getElementById('totalJobsStat'),
  savedJobsStat: document.getElementById('savedJobsStat'),
  appliedJobsStat: document.getElementById('appliedJobsStat'),
  interviewJobsStat: document.getElementById('interviewJobsStat'),
  exportBtn: document.getElementById('exportBtn'),
  importInput: document.getElementById('importInput'),
  loadDemoBtn: document.getElementById('loadDemoBtn'),
  resetFormBtn: document.getElementById('resetFormBtn'),
  themeToggle: document.getElementById('themeToggle'),
  parseJobBtn: document.getElementById('parseJobBtn'),
  syncFeedBtn: document.getElementById('syncFeedBtn'),
  template: document.getElementById('jobCardTemplate')
};

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = event => {
      const database = event.target.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('status', 'status', { unique: false });
        store.createIndex('category', 'category', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
  });
}

function tx(mode = 'readonly') {
  return db.transaction(STORE_NAME, mode).objectStore(STORE_NAME);
}

function getAllJobs() {
  return new Promise((resolve, reject) => {
    const request = tx().getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error);
  });
}

function saveJob(job) {
  return new Promise((resolve, reject) => {
    const request = tx('readwrite').put(job);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

function deleteJob(id) {
  return new Promise((resolve, reject) => {
    const request = tx('readwrite').delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function replaceAllJobs(nextJobs) {
  await new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    store.clear();
    nextJobs.forEach(job => store.put(job));
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
}

function normaliseJob(raw) {
  return {
    id: raw.id || crypto.randomUUID(),
    title: (raw.title || '').trim(),
    company: (raw.company || '').trim(),
    url: (raw.url || '').trim(),
    category: raw.category || 'other',
    region: raw.region || 'global',
    status: raw.status || 'saved',
    tags: Array.isArray(raw.tags) ? raw.tags : String(raw.tags || '').split(',').map(t => t.trim()).filter(Boolean),
    notes: (raw.notes || '').trim(),
    createdAt: raw.createdAt || new Date().toISOString()
  };
}

function filteredJobs() {
  return jobs
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .filter(job => {
      if (filters.category !== 'all' && job.category !== filters.category) return false;
      if (filters.status !== 'all' && job.status !== filters.status) return false;
      if (filters.region !== 'all' && job.region !== filters.region) return false;
      if (filters.search) {
        const haystack = [job.title, job.company, job.notes, job.tags.join(' ')].join(' ').toLowerCase();
        if (!haystack.includes(filters.search.toLowerCase())) return false;
      }
      return true;
    });
}

function renderFilterChips(container, dictionary, key) {
  container.innerHTML = '';
  Object.entries(dictionary).forEach(([value, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'chip' + (filters[key] === value ? ' active' : '');
    button.textContent = label;
    button.addEventListener('click', () => {
      filters[key] = value;
      renderAll();
    });
    container.appendChild(button);
  });
}

function statusAdvance(current) {
  const order = ['saved', 'applied', 'interview', 'offer', 'closed'];
  const index = order.indexOf(current);
  return order[(index + 1) % order.length];
}

function fillForm(job) {
  editingId = job.id;
  els.jobForm.id.value = job.id;
  els.jobForm.title.value = job.title;
  els.jobForm.company.value = job.company;
  els.jobForm.url.value = job.url;
  els.jobForm.category.value = job.category;
  els.jobForm.region.value = job.region;
  els.jobForm.status.value = job.status;
  els.jobForm.tags.value = job.tags.join(', ');
  els.jobForm.notes.value = job.notes;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function resetEditing() {
  editingId = null;
  els.jobForm.reset();
  els.jobForm.status.value = 'saved';
  els.jobForm.category.value = 'tech';
  els.jobForm.region.value = 'global';
  els.jobForm.id.value = '';
}

function renderJobs() {
  const items = filteredJobs();
  els.jobList.innerHTML = '';
  els.resultsText.textContent = `${items.length} ${items.length === 1 ? 'job' : 'jobs'}`;

  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = '<p>No jobs match your current filters yet.</p><p>Try loading demo jobs or widening your search.</p>';
    els.jobList.appendChild(empty);
    return;
  }

  items.forEach(job => {
    const node = els.template.content.firstElementChild.cloneNode(true);
    node.querySelector('.job-title').textContent = job.title;
    node.querySelector('.job-company').textContent = job.company;
    node.querySelector('.status-pill').textContent = STATUS_LABELS[job.status] || job.status;
    node.querySelector('.category-text').textContent = CATEGORY_LABELS[job.category] || job.category;
    node.querySelector('.region-text').textContent = REGION_LABELS[job.region] || job.region;
    node.querySelector('.notes-text').textContent = job.notes || 'No notes added yet.';
    const link = node.querySelector('.job-link');
    if (job.url) {
      link.href = job.url;
      link.textContent = 'Open source link';
    } else {
      link.removeAttribute('href');
      link.textContent = 'No source link saved';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.6';
    }

    const tagRow = node.querySelector('.tag-row');
    job.tags.forEach(tag => {
      const chip = document.createElement('span');
      chip.className = 'badge';
      chip.textContent = tag;
      tagRow.appendChild(chip);
    });
    if (!job.tags.length) {
      const chip = document.createElement('span');
      chip.className = 'badge';
      chip.textContent = 'No tags';
      tagRow.appendChild(chip);
    }

    node.querySelector('.action-edit').addEventListener('click', () => fillForm(job));
    node.querySelector('.action-delete').addEventListener('click', async () => {
      const confirmed = confirm(`Delete "${job.title}" from your tracker?`);
      if (!confirmed) return;
      await deleteJob(job.id);
      jobs = jobs.filter(item => item.id !== job.id);
      renderAll();
    });
    node.querySelector('.action-advance').addEventListener('click', async () => {
      const updated = { ...job, status: statusAdvance(job.status) };
      await saveJob(updated);
      jobs = jobs.map(item => item.id === job.id ? updated : item);
      renderAll();
    });

    els.jobList.appendChild(node);
  });
}

function renderStats() {
  els.totalJobsStat.textContent = jobs.length;
  els.savedJobsStat.textContent = jobs.filter(job => job.status === 'saved').length;
  els.appliedJobsStat.textContent = jobs.filter(job => job.status === 'applied').length;
  els.interviewJobsStat.textContent = jobs.filter(job => job.status === 'interview').length;
}

function renderAll() {
  renderFilterChips(els.categoryFilters, CATEGORY_LABELS, 'category');
  renderFilterChips(els.statusFilters, STATUS_LABELS, 'status');
  renderFilterChips(els.regionFilters, REGION_LABELS, 'region');
  renderJobs();
  renderStats();
}

async function hydrate() {
  jobs = await getAllJobs();
  renderAll();
}



function dedupeJobs(list) {
  const seen = new Set();
  return list.filter(job => {
    const key = `${job.title.toLowerCase()}__${job.company.toLowerCase()}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function importAutoCollectedFeed() {
  try {
    const response = await fetch('./data/remote-jobs-feed.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('Feed not available');
    const payload = await response.json();
    const incoming = Array.isArray(payload.jobs) ? payload.jobs.map(normaliseJob) : [];
    const merged = dedupeJobs([...incoming, ...jobs]);
    await replaceAllJobs(merged);
    jobs = merged;
    renderAll();
    alert(`Imported ${incoming.length} jobs from the auto-collected feed.`);
  } catch (error) {
    alert('No auto-collected feed could be loaded yet. If you host this on GitHub Pages, run the GitHub Action first or upload a generated feed file.');
  }
}

function parseHtmlMetadata(html, url) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  let title = '';
  let company = '';
  let region = 'global';

  const scripts = [...doc.querySelectorAll('script[type="application/ld+json"]')];
  for (const script of scripts) {
    try {
      const parsed = JSON.parse(script.textContent);
      const items = Array.isArray(parsed) ? parsed : [parsed];
      for (const item of items) {
        const type = item['@type'] || item['type'];
        if (type === 'JobPosting') {
          title = title || item.title || item.name || '';
          company = company || item.hiringOrganization?.name || '';
          const locationText = JSON.stringify(item.jobLocation || '').toLowerCase();
          if (locationText.includes('emea')) region = 'emea';
          else if (locationText.includes('africa')) region = 'africa';
          else if (locationText.includes('america')) region = 'americas';
          else if (locationText.includes('apac') || locationText.includes('asia')) region = 'apac';
        }
      }
    } catch (error) {
    }
  }

  if (!title) {
    title = doc.querySelector('meta[property="og:title"]')?.content
      || doc.querySelector('meta[name="twitter:title"]')?.content
      || doc.querySelector('title')?.textContent
      || '';
  }

  if (!company) {
    company = doc.querySelector('meta[property="og:site_name"]')?.content
      || doc.querySelector('meta[name="application-name"]')?.content
      || '';
  }

  title = title.replace(/\s*[|\-–—].*$/, '').trim();
  if (!company && url) {
    try {
      company = new URL(url).hostname.replace(/^www\./, '').split('.')[0];
      company = company.charAt(0).toUpperCase() + company.slice(1);
    } catch (error) {
    }
  }

  return { title, company, region };
}

async function quickImportFromUrl() {
  const url = prompt('Paste the job posting URL you want to import:');
  if (!url) return;
  try {
    new URL(url);
  } catch (error) {
    alert('Please enter a valid URL starting with http:// or https://');
    return;
  }

  let html = '';
  try {
    const response = await fetch(url);
    html = await response.text();
  } catch (error) {
    alert('This page could not be fetched directly from the browser. That can happen because some job sites block cross-origin requests. You can still paste the details manually.');
    els.jobForm.url.value = url;
    return;
  }

  const parsed = parseHtmlMetadata(html, url);
  els.jobForm.url.value = url;
  if (parsed.title) els.jobForm.title.value = parsed.title;
  if (parsed.company) els.jobForm.company.value = parsed.company;
  if (parsed.region) els.jobForm.region.value = parsed.region;
  if (!els.jobForm.notes.value) {
    els.jobForm.notes.value = 'Imported from URL metadata. Review and correct anything before saving.';
  }
  alert('Imported what could be detected from the page metadata. Please review the fields before saving.');
}

els.jobForm.addEventListener('submit', async event => {
  event.preventDefault();
  const formData = new FormData(els.jobForm);
  const payload = normaliseJob({
    id: editingId || formData.get('id') || crypto.randomUUID(),
    title: formData.get('title'),
    company: formData.get('company'),
    url: formData.get('url'),
    category: formData.get('category'),
    region: formData.get('region'),
    status: formData.get('status'),
    tags: formData.get('tags'),
    notes: formData.get('notes'),
    createdAt: editingId ? jobs.find(job => job.id === editingId)?.createdAt : new Date().toISOString()
  });
  if (!payload.title || !payload.company) return;
  await saveJob(payload);
  const existingIndex = jobs.findIndex(job => job.id === payload.id);
  if (existingIndex >= 0) jobs[existingIndex] = payload;
  else jobs.push(payload);
  resetEditing();
  renderAll();
});

els.resetFormBtn.addEventListener('click', () => resetEditing());

els.searchInput.addEventListener('input', event => {
  filters.search = event.target.value.trim();
  renderJobs();
});

els.exportBtn.addEventListener('click', () => {
  const payload = {
    exportedAt: new Date().toISOString(),
    app: 'Remote Jobs Hub',
    jobs
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'remote-jobs-hub-backup.json';
  anchor.click();
  URL.revokeObjectURL(url);
});

els.importInput.addEventListener('change', async event => {
  const file = event.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const importedJobs = Array.isArray(parsed.jobs) ? parsed.jobs : [];
    const cleanJobs = importedJobs.map(normaliseJob).filter(job => job.title && job.company);
    await replaceAllJobs(cleanJobs);
    jobs = cleanJobs;
    renderAll();
    alert(`Imported ${cleanJobs.length} jobs.`);
  } catch (error) {
    alert('That file could not be imported. Please use a valid backup JSON file.');
  } finally {
    event.target.value = '';
  }
});

els.loadDemoBtn.addEventListener('click', async () => {
  const merged = [...jobs];
  demoJobs.forEach(job => {
    if (!merged.some(item => item.title === job.title && item.company === job.company)) {
      merged.push(job);
    }
  });
  await replaceAllJobs(merged);
  jobs = merged;
  renderAll();
});

els.parseJobBtn.addEventListener('click', quickImportFromUrl);
els.syncFeedBtn.addEventListener('click', importAutoCollectedFeed);

(function initTheme() {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  let mode = prefersDark ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', mode);
  els.themeToggle.addEventListener('click', () => {
    mode = mode === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', mode);
  });
})();

(async function init() {
  try {
    db = await openDatabase();
    resetEditing();
    await hydrate();
  } catch (error) {
    console.error(error);
    els.jobList.innerHTML = '<div class="empty-state"><p>IndexedDB could not be opened in this browser.</p><p>Try Chrome, Edge, or Firefox.</p></div>';
  }
})();
