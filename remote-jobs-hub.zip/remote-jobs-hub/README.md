
# Remote Jobs Hub

A local-first remote job tracker that can also be hosted on GitHub Pages.

## Features
- Save remote jobs from any job board
- Filter by category, status, region, and search text
- Edit, delete, and advance job stages
- Browser-side persistence with IndexedDB
- Export/import backups as JSON
- Static-site friendly for GitHub Pages

## Run locally
Open `remote-jobs-hub.html` in a modern browser.

## Host on GitHub Pages
1. Create a new GitHub repository.
2. Upload all files from this folder.
3. Rename `remote-jobs-hub.html` to `index.html` before pushing, because GitHub Pages serves `index.html` by default.
4. In GitHub, open **Settings > Pages**.
5. Set the publishing branch (usually `main`) and folder (`/root`).
6. Save and wait for the site URL to appear.

GitHub Pages supports static HTML, CSS, and JavaScript sites, and a main HTML file named `index.html` is the standard entry point for deployment. [web:56][web:60]

## Data note
Your jobs are stored in the browser using IndexedDB, so data stays tied to that browser/profile unless you export and import a backup file. IndexedDB is commonly used for local browser persistence in static apps. [web:48][web:51][web:52]


## Quick import helper
The app now includes a **Quick import from URL** action that tries to read page metadata and prefill the form. It first looks for JobPosting structured data such as `title` and `hiringOrganization`, then falls back to page metadata like `og:title` and `og:site_name`. Structured job metadata is commonly published using Schema.org JobPosting and JSON-LD, while social metadata often uses Open Graph tags like `og:title`. [web:66][web:67][web:71][web:74]

### Limitation
Some job boards block direct browser fetch requests because of cross-origin restrictions, so automatic prefilling will work on some sites and fail on others. When that happens, the app still keeps the pasted URL in the form so you can finish the entry manually. [code_file:64]


## Automatic job collection layer
The project now includes a scheduled feed builder that can run on GitHub Actions and write a JSON file back into the repository. GitHub Actions supports scheduled workflows using cron syntax, and this pattern is commonly used for automated scraping or feed generation in static-site setups. [web:96][web:98][web:103]

### Included files
- `scripts/build_feed.py` — downloads remote jobs from an RSS source and converts them into the app's JSON format.
- `.github/workflows/build-feed.yml` — runs the script every 6 hours and on manual trigger, then commits the updated JSON feed.
- `data/remote-jobs-feed.json` — the feed file your frontend can import.

### Feed source
The starter implementation uses Jobicy's remote jobs RSS/API feed format, which exposes queryable job feed parameters and can be used to build remote job applications. [web:110]

### How to use it
1. Push the full project to GitHub.
2. Rename `remote-jobs-hub.html` to `index.html` for GitHub Pages.
3. Enable GitHub Pages from the repository settings. GitHub Pages serves static sites from a repository branch/folder. [web:60]
4. Open the **Actions** tab and run **Build remote jobs feed** once, or wait for the schedule.
5. In the app, click **Import auto-collected feed** to load the generated jobs from `data/remote-jobs-feed.json`.

### Scope note
This first automated layer is feed-driven, not a full unrestricted scraper. RSS and structured feed sources are more stable and static-hosting-friendly than trying to browser-scrape arbitrary job boards directly. GitHub Actions is well suited to scheduled automation, while the frontend remains a static site. [web:96][web:101][web:104][web:107]
