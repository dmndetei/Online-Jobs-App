
import json
import re
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'remote-jobs-feed.json'
FEEDS = [
    {
        'name': 'Jobicy',
        'url': 'https://jobicy.com/?feed=job_feed'
    }
]

CATEGORY_MAP = {
    'supporting': 'support',
    'support': 'support',
    'customer support': 'support',
    'dev': 'tech',
    'developer': 'tech',
    'engineering': 'tech',
    'marketing': 'sales',
    'sales': 'sales',
    'design': 'creative',
    'writing': 'creative',
    'copywriting': 'creative',
    'operations': 'ops',
    'admin': 'ops'
}

REGION_MAP = {
    'worldwide': 'global',
    'global': 'global',
    'anywhere': 'global',
    'africa': 'africa',
    'emea': 'emea',
    'europe': 'emea',
    'america': 'americas',
    'usa': 'americas',
    'canada': 'americas',
    'apac': 'apac',
    'asia': 'apac',
    'australia': 'apac'
}


def fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 RemoteJobsHubBot/1.0'})
    with urllib.request.urlopen(req, timeout=30) as response:
        return response.read()


def text_of(node, path, default=''):
    found = node.find(path)
    if found is None or found.text is None:
        return default
    return found.text.strip()


def classify_category(title: str, category_text: str) -> str:
    blob = f"{title} {category_text}".lower()
    for key, value in CATEGORY_MAP.items():
        if key in blob:
            return value
    return 'other'


def classify_region(text: str) -> str:
    blob = (text or '').lower()
    for key, value in REGION_MAP.items():
        if key in blob:
            return value
    return 'global'


def clean_tags(text: str):
    bits = re.split(r'[,|/]+', text or '')
    return [b.strip() for b in bits if b.strip()][:6]


def parse_jobicy(xml_bytes: bytes):
    root = ET.fromstring(xml_bytes)
    items = []
    namespaces = {
        'job': 'https://jobicy.com/ns/1.0',
        'dc': 'http://purl.org/dc/elements/1.1/'
    }
    for item in root.findall('./channel/item')[:80]:
        title = text_of(item, 'title')
        link = text_of(item, 'link')
        company = text_of(item, 'job:company', '') if item.find('job:company', namespaces) is not None else ''
        region_text = text_of(item, 'job:region', '') if item.find('job:region', namespaces) is not None else ''
        category_text = text_of(item, 'job:jobCategory', '') if item.find('job:jobCategory', namespaces) is not None else ''
        tags_text = text_of(item, 'category')
        pub_date = text_of(item, 'pubDate')
        created_at = datetime.now(timezone.utc).isoformat()
        if pub_date:
            try:
                created_at = datetime.strptime(pub_date, '%a, %d %b %Y %H:%M:%S %z').astimezone(timezone.utc).isoformat()
            except Exception:
                pass
        if not company:
            company = 'Unknown company'
        items.append({
            'id': f"jobicy-{abs(hash(link))}",
            'title': title,
            'company': company,
            'url': link,
            'category': classify_category(title, category_text),
            'region': classify_region(region_text),
            'status': 'saved',
            'tags': clean_tags(category_text or tags_text),
            'notes': f'Imported automatically from Jobicy RSS. Region text: {region_text or "Not specified"}.',
            'createdAt': created_at
        })
    return items


def dedupe(items):
    seen = set()
    out = []
    for job in items:
      key = (job['title'].strip().lower(), job['company'].strip().lower())
      if key in seen:
          continue
      seen.add(key)
      out.append(job)
    return out


def main():
    collected = []
    for feed in FEEDS:
        try:
            blob = fetch(feed['url'])
            if feed['name'] == 'Jobicy':
                collected.extend(parse_jobicy(blob))
            time.sleep(1)
        except Exception as exc:
            print(f'Failed to fetch {feed["name"]}: {exc}')
    collected = dedupe(collected)
    payload = {
        'generatedAt': datetime.now(timezone.utc).isoformat(),
        'source': 'github-actions-feed',
        'jobs': collected
    }
    OUT.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    print(f'Wrote {len(collected)} jobs to {OUT}')


if __name__ == '__main__':
    main()
